# Examples

Real descriptions from the knowledge-base ingestion pipeline, after the
verification pass.

## Feature: new components nothing calls yet

```text
feat(parsing): procedure header/footer detection and metadata extraction
```

```markdown
Adds the first two pieces of the procedure (SOP/WI documents) parser:
header/footer detection and metadata extraction. Nothing calls them yet; the
procedure parser will.

**Changes**

- `BoilerplateDetector`: a line in the top 8 or bottom 7 lines of at least half the pages is running header or footer, and `strip()` removes it only inside that zone, along with the per-page `Page Number: N of M` footer.
- `BoilerplateDetector.header_cells()`: the first page's header lines with their left edge, taken from the extracted line geometry when there is one.
- `MetadataExtractor`: reads `document_number`, `subtype`, `title`, `owning_department`, `version` (`Revision:` or `Version:`) and `effective_date` (`YYYY-MM`). The keys are the ones `PROCEDURE_PROFILE` already projects onto chunks; `lifecycle_state` and `owner` are always `None`.
- `subtype` comes from the cover's marker phrase or the class field of a regional document number, never from the filename.
- The document-number pattern finds the document's own number in the body; it never validates one.
- Unit tests for both modules (40): the header and footer zones and the page threshold pinned from both sides, the column split, both numbering schemes, every `subtype` signal, the version and date formats.

**Review notes**

- The anchors are template-specific: id patterns, marker variants, the 0.55 column split.
- Corpus evals run by the author: of the 22 documents in the procedure eval corpus, the 20 printed from the template are labelled correctly (17 SOPs, 3 Work Instructions); the other two print no header.

**Known gaps**

- No code reads a document-catalog record yet, so the header is the only source of these fields.
```

What the verification pass changed in this one:

- The first draft said "a catalog-registered document already carries these
  fields and that copy wins". No code reads a catalog record, so it became a
  Known gap, and the field names were anchored to `PROCEDURE_PROFILE`, which is
  in the repository, instead of to the catalog's schema, which is not.
- It said "Unit tests for both modules", but the test file covered
  `header_cells()` only. The pass reported `detect()` and `strip()` as
  untested; the author added their tests before review, and the bullet now
  says what they pin.
- It listed six docstrings and comments that still said the catalog copy wins;
  the author reworded them in the same push.

## Fix: behavior change with a measured effect

```text
fix(parsing): carry a heading with no body only into its own children
```

```markdown
Fixes where the procedure (SOP/WI documents) heading grammar puts a heading
that has no body of its own. It was always carried into the next section, which
put one-line clauses under a sibling's heading and dropped a bodiless heading at
the end of a document, with its text.

**Changes**

- A heading with no body opens the next section only when that section is its child (`5.` into `5.1`); otherwise it keeps a section of its own, which the chunker folds back when it is short.
- The last heading of a document is kept even when it has no body.
- A bare title with no line of its own before the next heading stays in the body as text: a diagram's phase, the last line of a checklist item. `N/A` is never a title.
- Unit tests for each case assert that the text stays in its section, not only the section titles.

**Review notes**

- Measured on the 22-document procedure eval corpus: no body line lost in any document, 2 previously dropped lines recovered, and the share of chunks holding a single section went from 0.937 to 0.966 on the training split.
```

## Rewrite: from a long draft to the format

A draft opened with two dense paragraphs of background, then listed 24 bullets,
one per helper (`Order a section's regions by
page, then top, then left`, `Keep lines under 4 characters`, ...). The rewrite
kept one opening sentence and folded the helpers into the behavior they serve:

```markdown
- `attach_region_blocks`: each table or figure region goes to the section whose lines it encloses (competing tables excluded), as a `body_blocks` entry with its box and, once vision has run, its Markdown.
- An interpreted table's raw text lines leave the body; an uninterpreted table keeps its raw text, so nothing is lost.
```

The two facts the long draft buried became **Known gaps**, where a reviewer
sees them:

```markdown
**Known gaps**

- `owning_facility` is a constructor argument with no production caller yet, so it reads `None` for now.
- `figure_count` counts detected figure regions only; embedded raster images are not counted yet.
```
