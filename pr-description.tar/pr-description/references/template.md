# PR description template

## Title

```text
<type>(<scope>): <summary>
```

`type` is one of `feat`, `fix`, `refactor`, `perf`, `test`, `docs`, `build`,
`ci`, `chore`; `scope` is the area as the repository's history names it.

## Body

```markdown
<One or two sentences: what this PR adds or fixes, and where it fits. If nothing
calls the new code yet, say so and name the component that will.>

**Changes**

- `<Component>`: <the behavior it adds or changes, in 1-2 sentences>.
- `<Component>`: <...>.
- <A behavior that spans components, stated once>.
- Unit tests for <what they cover>.

**Review notes**

- <Where to look hardest, or a decision a reviewer may question.>
- <A measured result: what was measured, on what, the number, and its source.>

**Known gaps**

- <What is deliberately not done, or public behavior left without a test, and its consequence today.>
```

Drop **Review notes** or **Known gaps** when there is nothing to put in them.

## Checklist

- [ ] Every claim has evidence: the diff, the base branch, or a command output.
- [ ] Nothing in another service or a later PR is stated as present.
- [ ] Every public behavior the PR adds is tested, or listed as a gap.
- [ ] Numbers were measured, and say on what.
- [ ] About 6 bullets of 1-2 sentences, about 250 words in all.
- [ ] Docstrings in the diff that make a false claim are listed for the user.
