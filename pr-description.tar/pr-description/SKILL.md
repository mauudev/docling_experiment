---
name: pr-description
description: >
  Write, rewrite or review a pull request title and description from the actual
  diff, in a short standard format (summary, changes, review notes) where every
  claim is checked against the code before it is shown. Use when the user asks
  to write, draft, improve, shorten, update or review a PR description, PR body
  or PR title, or to open a pull request.
---

# PR description

A good description lets a reviewer understand what changed, and where to look
hardest, in under a minute. It is short, and nothing in it is untrue. The second
property is the harder one: a description drafted from intent, commit messages
or a plan drifts from the code, and a reviewer who finds one false claim stops
trusting the rest.

## Workflow

1. **Find the diff.** Fetch first, then compare against the remote ref of the
   default branch (`origin/main`, not a possibly stale local `main`), or against
   the PR underneath for a stacked PR. If a PR already exists, read it first:

   ```bash
   git fetch origin
   gh pr view <number> --json title,body,baseRefName,headRefName,files
   git log --oneline origin/main..HEAD
   git diff --stat origin/main...HEAD
   git diff origin/main...HEAD
   ```

2. **Read the code, not only the commit messages.** List the behaviors the PR
   adds, changes or removes, and who calls the new code. If nothing calls it
   yet, say so. To name the future caller, search the other branches for it
   and name the component, not the branch or the PR number.
3. **Collect the facts you will state.** Test counts come from a run you can
   see, line counts from `git diff --numstat`. A result you cannot reproduce
   from the branch (a benchmark, a corpus run) stays only if the user gives
   you its source; otherwise ask for it, or leave it out.
4. **Draft** the title and body with
   [references/template.md](references/template.md). For calibration, read
   [references/examples.md](references/examples.md).
5. **Verify every claim** (mandatory, see below).
6. **Deliver** the title and body in two fenced blocks, ready to paste, and say
   what the verification pass changed. Update GitHub only when the user asks:

   ```bash
   gh pr edit <number> --title "<title>" --body-file <file>
   gh pr create --base <base> --title "<title>" --body-file <file>
   ```

## Format

**Title.** Follow the style of the repository's recent merged PR titles. When
it is mixed or absent, use Conventional Commits, `type(scope): summary`: a
short lowercase noun phrase or imperative, no trailing period, at most 72
characters.

**Body**, about 250 words at most, code excluded:

- **Opening**, 1-2 sentences: what the PR adds and where it fits.
- **Changes**, about 6 bullets and never more than 8, each 1-2 sentences: one
  per behavior a reviewer or a caller can observe, not one per function. When
  a bullet is about one component, lead with its name in backticks.
- **Review notes**, optional and at most 3: where to look hardest, a decision a
  reviewer may question, a measured result with its source.
- **Known gaps**, optional and at most 3: what is deliberately left undone, and
  its consequence today. Public behavior the PR adds without a test goes here.

**Writing rules.**

- Plain words. Define, in parentheses at first use, the two or three domain
  terms a reviewer from another team would not know: "procedure (SOP/WI
  documents)".
- The reason for a change fits in one clause. Background belongs in a design
  doc, not in the PR.
- No references to what the reviewer cannot open: internal plan files, private
  PR numbering, local paths.
- No AI attribution line unless the repository's convention asks for one.
- One bullet says what the tests cover. Give the count only if you ran them.
- Spell identifiers exactly as in the code.

## Verify every claim

Before showing the description, go through it sentence by sentence and point
each claim to its evidence: a file and symbol in the diff or in the base
branch, or a command output you have seen.

- A claim you cannot point to is removed, or rewritten until you can.
- A claim about another system or about intent ("the fields match the
  catalog's schema") is anchored to something in the repository, such as a
  schema, profile or config the code is checked against, or worded as intent
  ("named to match the catalog"). A code comment alone is not evidence.
- A claim about something that does not exist yet ("the catalog copy wins")
  moves to **Known gaps**, as future work.
- "Unit tests for X" is checked against the test files: a public method with
  no test is a Known gap, not covered.
- "Nothing calls it yet" is checked with a search for callers.

Docstrings and comments in the diff often make the same false claim. List them
for the user with `file:line` and a proposed rewording; change them only when
asked, and do not describe them in the PR.

## Reviewing an existing description

Run the same verification pass on the current text first. Report each claim
that does not hold, with its evidence, then propose the rewrite. Keep the
author's title unless it misnames the change.

## Anti-patterns

| Pattern | Fix |
| --- | --- |
| A capability that lives in another service or a future PR, stated as present | Move it to **Known gaps** |
| "Unit tests for both modules" when one module's main methods have none | Say what is tested; list the rest as a gap |
| Several paragraphs of background before the changes | One opening sentence; the rest goes in a design doc |
| One bullet per helper function, 15 or more bullets | One bullet per behavior, about 6 |
| Bullets of 60 words | 1-2 sentences each |
| "About 500 lines", "should be faster" | Measure it, or drop it |
| "Robust", "seamless", "comprehensive" | Say what it does |
